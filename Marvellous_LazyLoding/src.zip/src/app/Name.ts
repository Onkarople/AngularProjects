export interface Names
{   
    Name: String,
    Age : number,
    Salary: number
}